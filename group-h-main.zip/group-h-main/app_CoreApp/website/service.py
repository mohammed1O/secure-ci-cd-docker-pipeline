import json
import logging
import os
import time

import pymongo
import redis
from neo4j import GraphDatabase


# Configuration Constants


# MongoDB Configuration
MOVIES_MONGODB_CONFIG_URI = os.getenv(
    'MOVIES_MONGODB_CONFIG_URI', "mongodb://localhost:27017/"
)
MOVIES_MONGODB_DB = "test"
MOVIES_MONGODB_COLLECTION = "TMDB_dataset"

# Redis Configuration
MOVIES_REDIS_HOST = os.getenv('MOVIES_REDIS_HOST', '127.0.0.1')
MOVIES_REDIS_PORT = int(os.getenv('MOVIES_REDIS_PORT', 7000))
DEFAULT_CACHE_EXPIRATION = 300  # 5 minutes

# Neo4j Configuration
MOVIES_NEO4J_HOST = os.getenv('MOVIES_NEO4J_HOST', "neo4j://localhost")
NEO4J_AUTH = ("", "")


# Logging Configuration


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)


# MongoDB Setup


mongo_client = pymongo.MongoClient(MOVIES_MONGODB_CONFIG_URI)
db = mongo_client[MOVIES_MONGODB_DB]
movies = db[MOVIES_MONGODB_COLLECTION]


# Redis Setup


redis_db = redis.Redis(
    host=MOVIES_REDIS_HOST,
    port=MOVIES_REDIS_PORT,
    decode_responses=True
)


# Neo4j Setup

while True:
    try:
        with GraphDatabase.driver(
            MOVIES_NEO4J_HOST, auth=NEO4J_AUTH
        ) as neo4j_driver:
            neo4j_driver.verify_connectivity()
            logging.info("Connected to Neo4j")
            break
    except Exception as e:
        logging.error(
            f"Connection failed: {e}. Retrying in 5 seconds..."
        )
        time.sleep(5)


# Function


def search_movie(text):
    """
    Search movies by title. Sort results by popularity, text score,
    and rating. Return facets for `genre`, `releaseYear`, and `votes`.

    Hint: check MongoDB's $facet stage.
    """

    search_result = movies.aggregate([
        {"$match": {"$text": {"$search": text}}},
        {"$sort": {"score": {"$meta": "textScore"}, "vote_average": -1}},
        {"$facet": {
            "genreFacet": [
                {"$sortByCount": "$genres"}
            ],
            "releaseYearFacet": [
                {"$sortByCount": {"$year": "$release_date"}}
            ],
            "searchResults": [
                {"$project": {
                    "_id": 1,
                    "poster_path": 1,
                    "release_date": 1,
                    "score": {"$meta": "textScore"},
                    "title": 1,
                    "vote_average": 1,
                    "vote_count": 1
                }}
            ],
            "votesFacet": [
                {"$sortByCount": {"$round": "$vote_average"}}
            ]
        }}
    ])

    for search_doc in search_result:
        return search_doc

    return {}


def get_top_rated_movies():
    """
    Return top rated 25 movies with more than 5k votes.
    """
    redis_key = "top_rated_movies"
    if redis_db.exists(redis_key):
        json_top_rated_movies = redis_db.get(redis_key)
        return json.loads(json_top_rated_movies)
    else:
        top_rated_movies = list(
            movies.aggregate([
                {"$match": {"vote_count": {"$gt": 5000}}},
                {"$sort": {"vote_average": -1}},
                {"$limit": 25},
                {"$project": {
                    "_id": 1,
                    "poster_path": 1,
                    "release_date": 1,
                    "title": 1,
                    "vote_average": 1,
                    "vote_count": 1
                }}
            ])
        )
        json_top_rated_movies = json.dumps(
            top_rated_movies, default=str
        )
        redis_db.set(
            redis_key,
            json_top_rated_movies,
            ex=DEFAULT_CACHE_EXPIRATION
        )
        return top_rated_movies


def get_recent_released_movies():
    """
    Return recently released movies that have been reviewed
    by at least 50 users.
    """
    redis_key = "recent_released_movies"
    if redis_db.exists(redis_key):
        json_recent_released_movies = redis_db.get(redis_key)
        return json.loads(json_recent_released_movies)
    else:
        recent_released_movies = list(
            movies.aggregate([
                {"$match": {"vote_count": {"$gt": 50}}},
                {"$sort": {"release_date": -1}},
                {"$limit": 25},
                {"$project": {
                    "_id": 1,
                    "poster_path": 1,
                    "release_date": 1,
                    "title": 1,
                    "vote_average": 1,
                    "vote_count": 1
                }}
            ])
        )
        json_recent_released_movies = json.dumps(
            recent_released_movies, default=str
        )
        redis_db.set(
            redis_key,
            json_recent_released_movies,
            ex=DEFAULT_CACHE_EXPIRATION
        )
        return recent_released_movies


def get_movie_details(movie_id):
    """
    Return detailed information for the specified movie_id.
    """
    redis_key = f"movie_details_{movie_id}"

    if redis_db.exists(redis_key):
        json_movie_details = redis_db.get(redis_key)
        redis_db.expire(redis_key, DEFAULT_CACHE_EXPIRATION)
        return json.loads(json_movie_details)
    else:
        movie_details = movies.find_one(
            {"_id": movie_id},
            {
                "_id": 1,
                "genres": 1,
                "overview": 1,
                "poster_path": 1,
                "release_date": 1,
                "tagline": 1,
                "title": 1,
                "vote_average": 1,
                "vote_count": 1
            }
        )

        json_movie_details = json.dumps(movie_details, default=str)
        redis_db.set(
            redis_key,
            json_movie_details,
            ex=DEFAULT_CACHE_EXPIRATION
        )
        return movie_details


def get_similar_movies(movie_id, genres):
    """
    Return a list of movies that are similar based on provided genres.

    Movies are sorted by the number of matching genres in descending
    order.
    If multiple movies have the same number of matching genres, they are
    sorted by rating in descending order.

    Movies with fewer than 500 votes are excluded. The result is limited to
    10 movies.
    """

    similar_movies = movies.aggregate([
        {
            "$match": {
                "genres": {"$in": genres},
                "vote_count": {"$gt": 500},
                "_id": {"$ne": movie_id}
            }
        },
        {
            "$project": {
                "_id": 1,
                "genres": 1,
                "poster_path": 1,
                "release_date": 1,
                "title": 1,
                "vote_average": 1,
                "vote_count": 1
            }
        },
        {"$unwind": "$genres"},
        {
            "$group": {
                "_id": "$_id",
                "genres_count": {"$sum": 1},
                "poster_path": {"$first": "$poster_path"},
                "release_date": {"$first": "$release_date"},
                "title": {"$first": "$title"},
                "vote_average": {"$first": "$vote_average"},
                "vote_count": {"$first": "$vote_count"}
            }
        },
        {"$sort": {"genres_count": -1, "vote_average": -1}},
        {"$limit": 10}
    ])

    return list(similar_movies)


def get_movie_likes(username, movie_id):
    """
    Returns a list of usernames of users who also like the specified movie_id.
    """
    with neo4j_driver.session() as session:
        result = session.run(
            '''
            MATCH (s1:Student {name: $username})
            MATCH (m:Movie {id: $movie_id})-[:IS_FAVOURITE]-(s2:Student)
            WHERE s2 <> s1
            RETURN s2.name AS name
            ''',
            username=username,
            movie_id=movie_id
        )

        username_list = [record["name"] for record in result]
        return username_list


def get_recommendations_for_me(username):
    """
    Return up to 10 movie recommendations based on similar users' tastes.
    """
    with neo4j_driver.session() as session:
        movie_ids = session.run(
            '''
            MATCH (s1:Student {name: $username})-[:IS_FAVOURITE]-(m:Movie)-[
                :IS_FAVOURITE]-(s2:Student)
            WITH s2, COUNT(m) AS common_movies
            ORDER BY common_movies DESC
            LIMIT 5
            MATCH (s2)-[:IS_FAVOURITE]-(m_s2:Movie)
            WHERE NOT (s1)-[:IS_FAVOURITE]-(m_s2)
            WITH m_s2, COUNT(*) AS stars
            ORDER BY stars DESC
            LIMIT 10
            RETURN m_s2.id AS movie_id
            ''',
            username=username
        )

        recommended_movies = []
        for record in movie_ids:
            movie_detail = get_movie_details(record["movie_id"])
            recommended_movies.append(movie_detail)

        return recommended_movies
